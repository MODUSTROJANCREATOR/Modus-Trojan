DO NOT RUN THIS SCRIPT IF YOU HAVE A WEAK PC

This script is intended for entertainment purposes only and should not be run on systems where performance may be compromised. It executes a series of actions that may cause annoyance and minor disruptions.

To stop the script:

1. If you encounter any issues or wish to stop the script, immediately press CTRL + ALT + DELETE.
2. Select "Sign out" from the options provided.
3. After signing out, do not run the script again.

Instructions:

1. Run the script only on systems where you have administrative privileges.
2. This script is a prank and should not be run on production or shared systems.

By running this script, you acknowledge that you are doing so at your own risk and that the author is not responsible for any inconvenience caused.

To reverse the effects of this script, manually rename any files with the ".NotFoundUsable" extension back to their original .exe .jpeg .png extension.

This script does encrypt  anything in the downloads folder so take a screenshot of the folder before you load so you can remember the extensions.

If you have any questions or concerns, please contact the author.
